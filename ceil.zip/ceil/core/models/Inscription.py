from django.conf import settings

from django.contrib import admin
from django.db import models
from django import forms
from core.models.Etudiant import Etudiant
from django.urls import reverse
from django.utils.html import format_html
from django.urls import include, re_path
from django.template.response import TemplateResponse



niveau = (
    ('A1', 'A1'),
    ('A2', 'A2'),
    ('B1', 'B1'),
    ('B2', 'B2'),
    ('C1', 'C1'),
    ('C2', 'C2'),
    )

langue = (
    ('Français','Français'),
    ('Anglais', 'Anglais'),
    ('Espagnol', 'Espagnol'),
    ('Russe', 'Russe'),
    ('Allemand', 'Allemand'),
    )
class InscriptionManager(models.Manager):
    def get_queryset(self):
        return super(InscriptionManager, self).get_queryset().filter(anneeuniv=settings.ANNEE_UNIV)

class Inscription(models.Model):


    id_etudiant = models.ForeignKey('Etudiant',
                                           models.DO_NOTHING,
                                           db_column='id_etudiant',
                                           verbose_name='Matricule'
                                           )

    langue = models.CharField(max_length=10,choices=langue)
    niveau = models.CharField(max_length=2,choices=niveau)
    date_inscription = models.DateTimeField(auto_now_add = True)

    anneeuniv = models.CharField(max_length=9,
                                 default=settings.ANNEE_UNIV,
                                 verbose_name='Année universitaire')
    
    objects = InscriptionManager()

    
    def __str__(self):
        return '%s' % self.id_etudiant



    class Meta:
        db_table = 'base_inscription'
        unique_together = (('id_etudiant', 'langue', 'niveau'),)



class InscriptionAdmin(admin.ModelAdmin):
    model = Inscription
    list_per_page = 15
    raw_id_fields = ('id_etudiant',)
    list_display = ('id_etudiant','Print','langue','niveau')
    # view_on_site = False
    # list_display = ('id_etudiant','Print')
    save_as = True
    readonly_fields = ['anneeuniv',]
    search_fields = ('id_etudiant__nom_fr','id_etudiant__prenom_fr')
    ordering = ('-date_inscription',)

    def Print(self,obj):
        dest = reverse('admin:print',
                       kwargs={'pk': obj.pk})
        return format_html('<b><a href="{url}" style="color:green">{title}</a></b>',
                           url=dest, title='Attestation')
    Print.short_description = 'Imprimer attestation'

    def get_urls(self):
        urls = [
            re_path('^(?P<pk>\d+)/print/?$',
                self.admin_site.admin_view(self.pdf_view),
                name='print'),
        ]
        return urls + super(InscriptionAdmin, self).get_urls()

    def pdf_view(self, request, *args, **kwargs):

        # In this function we retrieves data from database and parse
        # this values to the template attestationsV2.html

        template = 'attestation.html'
        data1 = Inscription.objects.get(pk=kwargs['pk'])
        data2 = Etudiant.objects.get(pk=data1.id_etudiant.pk)
        context = {'inscription': data1,'etudiant':data2,}
        return TemplateResponse(request, template, context)


    def has_delete_permission(self, request, obj=None):
        return True

    def get_actions(self, request):
        actions = super(InscriptionAdmin, self).get_actions(request)
        if 'delete_selected' in actions:
            del actions['delete_selected']
        return actions
