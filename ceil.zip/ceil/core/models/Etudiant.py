import uuid
from django.contrib import admin
from django.core.validators import MinLengthValidator
from django.db import models
from django import forms

GENDER_CHOICES = (
    ('M', 'Masculin'),
    ('F', u'Féminin'),
)
class Etudiant(models.Model):
    nin = models.DecimalField(max_digits=18,
                              decimal_places=0,
                              blank=True,
                              null=True,
                              verbose_name='numéro NIN',
                              )


    id_etudiant = models.CharField(max_length=36, primary_key=True,
                                   default=uuid.uuid4, editable=False)

    matricule_etudiant = models.CharField(max_length=20,
                                          editable=True,
                                          blank=True,
                                          null=True,
                                          )

    nom_fr = models.CharField(max_length=100,
                              verbose_name='Nom Latin')


    prenom_fr = models.CharField(max_length=100,
                                 verbose_name='Prénom Latin')

    nom_ar = models.CharField(max_length=100,
                              verbose_name='Nom Arabe')

    prenom_ar = models.CharField(max_length=100,
                                 verbose_name='Prénom Arabe')

    presume = models.BooleanField(default=False)

    datenaiss = models.DateField(verbose_name='Date de naissance')

    # wilaya_naiss = models.CharField(max_length=50,
    #                                 blank=True,
    #                                 null=True,
    #                                 verbose_name='Wilaya de naissance')

    wilaya_naiss = models.CharField(max_length=100,
                                    verbose_name="Wilaya de naissance")



    commune_naiss = models.CharField(max_length=100,
                                          verbose_name="Commune de naissance")

    # wilayas_nouv = models.ForeignKey(Wilaya, on_delete=models.CASCADE)
    #
    # commune_nouv = models.ForeignKey(Commune, on_delete=models.CASCADE)

    sexe = models.CharField(max_length=1,
                            choices=GENDER_CHOICES)

    adresse = models.CharField(max_length=200, blank=True, null=True)

    email = models.CharField(max_length=50, blank=True, null=True)

    telephone = models.DecimalField(max_digits=10, decimal_places=0, blank=True, null=True,)
    
    def save(self, force_insert=False, force_update=False):
        self.nom_fr = self.nom_fr.upper()
        self.prenom_fr = self.prenom_fr.upper()
        return super(Etudiant, self).save()



    def __str__(self):
        return '%s %s' % (self.nom_fr,self.prenom_fr)

    class Meta:
        db_table = 'base_etudiant'



class EtudiantAdmin(admin.ModelAdmin):
    model = Etudiant
    list_per_page = 15
    def has_delete_permission(self, request, obj=None):
        return False

    def get_actions(self, request):
        actions = super(EtudiantAdmin, self).get_actions(request)
        if 'delete_selected' in actions:
            del actions['delete_selected']
        return actions
