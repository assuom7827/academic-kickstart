from django.contrib import admin
from core.models.Etudiant import Etudiant,EtudiantAdmin

from core.models.Inscription import Inscription, InscriptionAdmin


admin.site.register(Etudiant, EtudiantAdmin)
admin.site.register(Inscription, InscriptionAdmin)